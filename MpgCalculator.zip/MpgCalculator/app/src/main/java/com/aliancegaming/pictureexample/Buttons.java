package com.aliancegaming.pictureexample;

import android.os.Bundle;

interface Buttons {
    void onCreate(Bundle savedInstanceState);
}
